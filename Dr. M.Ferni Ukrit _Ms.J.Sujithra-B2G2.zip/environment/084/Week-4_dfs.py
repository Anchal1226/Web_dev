graph = {
  'A' : ['B','C'],
  'B' : ['D'],
  'C' : ['F','D'],
  'D' : ['E','F'],
  'E' : ['G'],
  'F' : ['G'],
  'G' : []
} 
visited = set()
 
def dfs(visited, graph, node):
    if node not in visited:
        print (node)
        visited.add(node)
        for neighbour in graph[node]:
            dfs(visited, graph, neighbour)
 
dfs(visited, graph, 'A')
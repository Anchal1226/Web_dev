graph = {
  'A' : ['B','C'],
  'B' : ['D'],
  'C' : ['F','D'],
  'D' : ['E','F'],
  'E' : ['G'],
  'F' : ['G'],
  'G' : []
}
 
visited = []
queue = []
 
def bfs(visited, graph, node):
    visited.append(node)
    queue.append(node)
    while queue:
        s = queue.pop(0) 
        print (s, end = " ") 
        for neighbour in graph[s]:
              if neighbour not in visited:
                    visited.append(neighbour)
                    queue.append(neighbour)


print("BFS :",end = " ")
bfs(visited, graph, 'A')

print("")

visited = set()
 
def dfs(visited, graph, node):
    if node not in visited:
        print (node,end = " ")
        visited.add(node)
        for neighbour in graph[node]:
            dfs(visited, graph, neighbour)
print("DFS :",end = " ") 
dfs(visited, graph, 'A')
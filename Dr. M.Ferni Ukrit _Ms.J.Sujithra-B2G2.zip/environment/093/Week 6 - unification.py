l1=[]
l2=[]
print("First Sentence:")
p1=input("Enter Predicate: ")
while True:
    st = input("Enter Arguement: ")
    if not st:
        break
    l1.append(st)
p2=input("Second Predicate: ")
while True:
    st = input("Enter Arguement: ")
    if not st:
        break
    l2.append(st)
#rule 1
if(p1!=p2):
    print("Predicate is not same.")
elif(len(l1)!=len(l2)):
    print("Number of arguements are not same.")
else:
    for i in range(len(l1)):
        print('({}|{})'.format(l1[i],l2[i]))
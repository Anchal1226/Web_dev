from queue import PriorityQueue
v = 16
graph = [[] for i in range(v)]

def best_first_search(source, target, n):
        visited =[0]*n
        pq=PriorityQueue()
        pq.put((0,source))
        while pq.empty()==False:
                u=pq.get()[1]
                print(u,end=" ")
                if u==target:
                        break
                for v,c in graph[u]:
                        if visited[v]==0:
                                visited[v]=1
                                pq.put((c,v))
        print()
	

def a(x, y, cost):
	graph[x].append((y, cost))
	graph[y].append((x, cost))

a(0,1,3),
a(0,3,5),
a(0,2,6),
a(1,4,9),
a(1,5,8),
a(2,6,12),
a(2,7,14),
a(3,8,7),
a(8,9,5),
a(8,10,6),
a(9,11,1),
a(9,12,10),
a(9,13,2),


source = 0
target = 9
best_first_search(source, target, v)